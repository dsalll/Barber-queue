# Barber Queue App

A live queue management app for barbershops.

## How to Deploy on Vercel

1. Go to github.com and create a free account
2. Create a new repository called `barber-queue`
3. Upload ALL the files in this folder (keep the folder structure)
4. Go to vercel.com and sign up with GitHub
5. Click "Add New Project" → select `barber-queue`
6. Click Deploy — done!

Your app will be live at: `barber-queue.vercel.app`

## Folder Structure

```
barber-queue/
├── index.html
├── package.json
├── vite.config.js
└── src/
    ├── main.jsx
    └── App.jsx
```
